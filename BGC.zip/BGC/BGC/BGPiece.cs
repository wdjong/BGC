﻿namespace BGC
{
    class BGPiece
    {
        public int PieceID { get; set; }
        public int Position { get; set; }
    }
}
